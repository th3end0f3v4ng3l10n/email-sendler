<h1>Email Sendler</h1>

----

<h3>DOCS</h3>
Привет, эта программа рассылает сообщение, которое записано в config.ini по почтам, которые записаны в emails. Работает через smtp GMAIL.
Потому, желательно использовать именно GMAIL.

----

<h3>INSTALL</h3>
Чтобы у вас всё правильно работало надо установить все зависимости:

    pip3 install -r requirements
    
Заполнить login и password в config.ini

И не забыть про файл emails. В него нужно вставить email адреса на которые вы будете отправлять сообщения

Тут https://myaccount.google.com/lesssecureapps?pli=1&rapt=AEjHL4Pp1XbEfdTLnkA1YzJzBLF5kUrsAXcsICUyRrQci_Jg-tPU-uxOBs-TdOEdzu1ilaQhCTjxKOv0MeywPFBwGoTI_VGHAg тыкнуть чтобы было разрешено

----

<h3>START</h3>
Для WINDOWS:
    
    python main.py

Для LINUX:

    python3 main.py
    
----
<h3>EXAMPLE</h3>

![Alt Text](https://github.com/th3end0f3v4ng3l10n/email-sendler/blob/main/example/gif.gif)
